﻿namespace SeaportmanagementPro
{
    partial class CarrierLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Rlogin = new System.Windows.Forms.Button();
            this.txt_rPass = new System.Windows.Forms.TextBox();
            this.txt_rId = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Rlogin
            // 
            this.btn_Rlogin.Location = new System.Drawing.Point(101, 227);
            this.btn_Rlogin.Name = "btn_Rlogin";
            this.btn_Rlogin.Size = new System.Drawing.Size(96, 29);
            this.btn_Rlogin.TabIndex = 5;
            this.btn_Rlogin.Text = "Login";
            this.btn_Rlogin.UseVisualStyleBackColor = true;
            // 
            // txt_rPass
            // 
            this.txt_rPass.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_rPass.Location = new System.Drawing.Point(12, 146);
            this.txt_rPass.Name = "txt_rPass";
            this.txt_rPass.Size = new System.Drawing.Size(312, 20);
            this.txt_rPass.TabIndex = 4;
            this.txt_rPass.Text = "Password";
            // 
            // txt_rId
            // 
            this.txt_rId.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_rId.Location = new System.Drawing.Point(12, 84);
            this.txt_rId.Name = "txt_rId";
            this.txt_rId.Size = new System.Drawing.Size(312, 20);
            this.txt_rId.TabIndex = 3;
            this.txt_rId.Text = "UserId";
            // 
            // CarrierLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 429);
            this.Controls.Add(this.btn_Rlogin);
            this.Controls.Add(this.txt_rPass);
            this.Controls.Add(this.txt_rId);
            this.Name = "CarrierLogin";
            this.Text = "CarrierLogin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Rlogin;
        private System.Windows.Forms.TextBox txt_rPass;
        private System.Windows.Forms.TextBox txt_rId;
    }
}